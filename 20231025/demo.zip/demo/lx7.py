"""
    os模块执行命令
"""

# 导入模块
import os

# 执行命令（运行当前目录指定的python文件）
os.system("python a.py")
# 列出当前目录
os.system("dir")