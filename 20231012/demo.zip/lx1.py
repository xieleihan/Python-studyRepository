# 同数据类型列表
list = ["java","python","cpp","goland"]
print(list)
print(type(list))
# 不同数据类型列表
list = ["java",False,30,400.9]
print(list)
print(type(list))
# 支持嵌套
list = [["java","python","cpp","goland"],[1000,8000,500]]
print(list)
print(type(list))